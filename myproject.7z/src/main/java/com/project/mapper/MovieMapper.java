package com.project.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.project.dto.MovieDTO;
@Mapper
public interface MovieMapper {
	int selectMovieCode();
	void insertMovie(MovieDTO dto);
	List<MovieDTO> selectAllMovie();
	MovieDTO selectMovieDTO(int mcode);
	int deleteMovie(String index);
}
