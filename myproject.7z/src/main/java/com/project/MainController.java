package com.project;

import java.io.File;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.project.Service.movieService;
import com.project.dto.MovieDTO;

@Controller
public class MainController {
	private movieService movieservice;
	
	@RequestMapping("/close.do")
	public String close(Model model, String mcode) {
		System.out.println(mcode);
		return "close";
	}

	@RequestMapping("/deletemovie.do")
	public String deretemovie(Model model, String mcode) {
		String[] index = mcode.split(",");
		/* String index = mcode.replace(","," or \"mcode\" = "); */
		System.out.println(index);
		movieservice.deleteMovie(index);
		return "redirect:/";
	}

	@RequestMapping("/test.do")
	public String test(Model model) {
		List<MovieDTO> list = movieservice.selectBoardList();
		model.addAttribute("list", list);
		return "test";
	}

	@RequestMapping("/test-1.do")
	public String test1(Model model) {
		System.out.println("1");
		List<MovieDTO> list = movieservice.selectBoardList();
		model.addAttribute("list", list);
		return "test-1";
	}


	public MainController(movieService movieservice) {
		this.movieservice = movieservice;
	}

	@RequestMapping("/")
	public String main(Model model) {
		List<MovieDTO> list = movieservice.selectBoardList();
		model.addAttribute("list", list);
		return "index-MyMovieList";
	}

	@RequestMapping("/insertMovie.do")
	public String example(HttpServletResponse response, MovieDTO dto) {
		return "insertMovie";
	}

	@RequestMapping("/openAPI2.do")
	public String test03(Model model) {
		return "openAPI2";
	}

	@RequestMapping("/index-MyMovieList.do")
	public String index(Model model) {
		List<MovieDTO> list = movieservice.selectBoardList();
		model.addAttribute("list", list);
		return "index-MyMovieList";
	}

	@RequestMapping("/index-insertMovie.do")
	public String index2(MovieDTO dto) {
		return "index-insertMovie";
	}

	@RequestMapping("/index-openAPI.do")
	public String index3(MovieDTO dto) {
		return "index-openAPI";
	}

	@RequestMapping("/table.do")
	public String table(MovieDTO dto) {
		return "table";
	}

	@RequestMapping("/MyMovieList.do")
	public String test04(Model model) {
		System.out.println("1");
		List<MovieDTO> list = movieservice.selectBoardList();
		System.out.println(list.toString());
		model.addAttribute("list", list);
		return "MyMovieList";
	}

	@RequestMapping("/uploadMovie.do")
	public String uploadMovie(MovieDTO dto) {
		System.out.println(dto);
		return "redirect:/";
	}

	@RequestMapping("/uploadmovie.do")
	public String boardWrite(MovieDTO dto, MultipartHttpServletRequest request) {
		int bno = movieservice.insertMovie(dto);
		/*
		 * //파일 업로드 //저장할 경로 String root = "c:\\fileUpload\\"; File userRoot = new
		 * File(root); if(!userRoot.exists()) userRoot.mkdirs();
		 * 
		 * List<MultipartFile> fileList = request.getFiles("file"); int i = 1;
		 * for(MultipartFile f : fileList) { String originalFileName =
		 * f.getOriginalFilename(); if(f.getSize() == 0) continue; File uploadFile = new
		 * File(root + "\\" +originalFileName); movieService.insertFileList(new
		 * FileDTO(uploadFile, bno, i)); i++; try { //실제로 전송 f.transferTo(uploadFile); }
		 * catch (IllegalStateException e) { e.printStackTrace(); } catch (IOException
		 * e) { e.printStackTrace(); } }
		 */
		System.out.println(bno);
		return "close";
	}

	@RequestMapping("/test04-1.do")
	public String test04_1(Model model) {
		List<MovieDTO> list = movieservice.selectBoardList();
		model.addAttribute("list", list);
		return "test04-1";
	}

	@RequestMapping("/movieView.do")
	public String movieView(int mcode, Model model, HttpSession session) {
		MovieDTO dto = movieservice.selectMovieDTO(mcode);
		model.addAttribute("movie", dto);
		/* model.addAttribute("flist", flist); */
		return "index-movie_detail_view";
	}

}